#KIS - Kerbal Inventory System
####Mod for [Kerbal Space Program](http://www.kerbalspaceprogram.com/)
===

KIS introduce new gameplay mechanics by adding a brand new inventory sytem and EVA usables items as tools. 
You want to build a rover on Duna from scratch? Now you can...

Main features

- KAS inventory system overhaul.
- Visual and user friendly inventory interface using drag and drop system.
- Unique EVA usable items as Screwdriver, Explosive charges or extra EVA fuel tank...
- Inventories for Kerbals.
- Stock alike containers and parts.
- Containers Mounts for easy container detachment and reattachment.
- Item stacking.
- Sounds effects.
- Clear code and .cfg modules to help other modders items creation.
- Standalone (KAS and ModuleManager is not needed).

===
Forum thread: [KIS](http://forum.kerbalspaceprogram.com/threads/113111-0-90-Kerbal-Inventory-System-%28KIS%29-1-0-0)  
