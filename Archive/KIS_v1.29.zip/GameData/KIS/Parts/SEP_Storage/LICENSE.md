# License

This work is presented under a Simplified BSD license.

# Overview

The parts in this subfolder are borrowed from the [SEP](https://forum.kerbalspaceprogram.com/index.php?/topic/155382-16x-surface-experiment-pack-deployable-science-for-kiskas-v27-13jan19/)
mod. All credits go to the respected authors.
