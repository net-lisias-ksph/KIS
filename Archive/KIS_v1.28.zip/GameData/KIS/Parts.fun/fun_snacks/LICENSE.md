# Sound sample

The sound for this fun part (`snacks.ogg`) was obtained from [this source](https://lasonotheque.org/detail-0352-bruits-de-bouche-1.html).
It's distributed under `CC0 1.0 Universal, Public Domain Dedication` license.

# Model, textures, and part CFG

The original author of these resources is [@Well](https://forum.kerbalspaceprogram.com/index.php?/profile/145290-well/),
who is releasing the resources under `Public Domain` license.
