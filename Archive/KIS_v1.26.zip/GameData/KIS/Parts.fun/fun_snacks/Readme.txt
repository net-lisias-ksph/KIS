
	ʕ•ᴥ•ʔ    SNACKS!   °(ᵔᴥᵔ)°

	This little fun part is made by Stéphane Colombain @Well
	Inspired by the 1.10 promo picture
	
	Gift for KIS Modder @IgorZ and KSP community