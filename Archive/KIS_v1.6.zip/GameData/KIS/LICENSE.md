**Copyright Overview**

- Models and textures was created by Winn75, who retains the copyright.
- Config files, source code and compiled binaries are under copyright retained by KospY.
 
**YOU MAY :**

- Distribute your own parts using any part modules included.
- Distribute fixes in case of a compatibility problem with a new version of KSP (.dll only).
- Distribute video, screenshots or other media portraying KIS in action.
- Distribute modified or unmodified versions of the KIS plugin source code on condition that a link to this license is included.
- Modify KIS in any way for personal use.
- Request a waiver of any of these terms.
 
**All other rights are reserved.**
